# Consent-Based Location Share — GitHub Ready

This repository contains the frontend for a consent-based location-sharing system.

## What it does

1. A recipient opens `share.html?id=...`.
2. They press **Allow & Share Location**.
3. The browser asks for location permission.
4. If permission is granted, GPS coordinates are sent to your backend.
5. The backend can store the location and send an email notification.
6. The email can contain a link to `location.html?id=...`.

## Important

GitHub Pages hosts the frontend only. It cannot safely send email or store private API credentials.

You therefore need a backend such as Google Apps Script, Cloudflare Workers, Vercel, or your own server.

This repository is intentionally configured with a placeholder backend URL:

`PASTE_YOUR_BACKEND_WEB_APP_URL_HERE`

Do NOT put SMTP passwords, API keys, or private credentials in GitHub frontend files.

## GitHub Pages

Upload the contents of `public/` to a GitHub repository and enable GitHub Pages.

Example share URL:

`https://YOUR-USERNAME.github.io/YOUR-REPO/share.html?id=demo-001`

## Backend contract

### POST

Send JSON to the backend URL:

```json
{
  "shareId": "demo-001",
  "latitude": 9.03,
  "longitude": 38.74,
  "accuracy": 12.5,
  "timestamp": "2026-10-05T00:00:00.000Z",
  "viewUrl": "https://YOUR-USERNAME.github.io/YOUR-REPO/location.html?id=demo-001"
}
```

The backend should return:

```json
{"ok":true}
```

### GET

For the map page:

`BACKEND_URL?shareId=demo-001`

Return:

```json
{
  "ok": true,
  "latitude": 9.03,
  "longitude": 38.74,
  "accuracy": 12.5,
  "timestamp": "2026-10-05T00:00:00.000Z"
}
```

## Email

The backend—not GitHub Pages—should send the notification to the owner's configured email address.

The user must explicitly grant browser location permission. This project does not bypass that permission.
