/*
  Replace only BACKEND_URL with your deployed backend Web App URL.
  Do not place email passwords or private API keys here.
*/
const CONFIG={
  BACKEND_URL:"PASTE_YOUR_BACKEND_WEB_APP_URL_HERE"
};
